package main;
import bo.CandidateBo;
import constant.IConstant;
import mock.Data;
import util.Validate;
public class Main {
    public static void main(String[] args) {
        CandidateBo candidateBo = new CandidateBo(Data.listCandidate);
        boolean flag = true;
        do {
            //Helper.menu();
            System.out.println("\nCANDIDATE MANAGEMENT SYSTEM");
            System.out.println("1. Experience");
            System.out.println("2. Fresher");
            System.out.println("3. Internship");
            System.out.println("4. Search");
            System.out.println("5. Exit");
            int choice = Validate.getInt(
                    "Enter your choice: ",
                    "Numeric value out of range",
                    "Invalid integer number",
                    1, 5);
            switch (choice) {
                case 1:
                    System.out.println();
                    candidateBo.add(IConstant.EXPERIENCE_TYPE);
                    break;
                case 2:
                    System.out.println();
                    candidateBo.add(IConstant.FRESHER_TYPE);
                    break;
                case 3:
                    System.out.println();
                    candidateBo.add(IConstant.INTERN_TYPE);
                    break;
                case 4:
                    System.out.println();
                    System.out.println("=======EXPERIENCE CANDIDATE=======");
                    candidateBo.displayCandidateNameByType(IConstant.EXPERIENCE_TYPE);
                    System.out.println("=======FRESHER CANDIDATE=======");
                    candidateBo.displayCandidateNameByType(IConstant.FRESHER_TYPE);
                    System.out.println("=======INTERN CANDIDATE=======");
                    candidateBo.displayCandidateNameByType(IConstant.INTERN_TYPE);
                    String text = Validate.getString(
                            "Input Candidate name(first name or last name): ",
                            "Invalid name",
                            IConstant.REGEX_NAME);
                    int type = Validate.getInt(
                            "Input type of candidate [0-1-2] "
                            + "(0: Experience, "
                            + "1: Fresher, "
                            + "2: Intern): ",
                            "Numeric value out of range",
                            "Invalid integer number",
                            0, 2);
                    candidateBo.display(candidateBo.search(text, type));
                    break;
                case 5:
                    flag = false;
                    break;

            }
        } while (flag);
    }

}
